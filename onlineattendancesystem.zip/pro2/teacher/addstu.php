<?php
$conn = mysqli_connect("localhost","root","","attsystem");
ob_start();
session_start();

if($_SESSION['name']!='oasis')
{
  header('location: login.php');
}
?>
<?php include('connect.php');?>

<?php

include('connect.php');

//data insertion
  try{

    //checking if the data comes from students form
    if(isset($_POST['std'])){

      //students data insertion to database table "students"
        $result = mysqli_query($conn,"insert into students(st_id,st_name,st_dept,st_batch,st_sem,st_email) values('$_POST[st_id]','$_POST[st_name]','$_POST[st_dept]','$_POST[st_batch]','$_POST[st_sem]','$_POST[st_email]')");
        $success_msg = "Student Added Successfully.";
		echo $success_msg;

    }
 }
  catch(Execption $e){
    $error_msg =$e->getMessage();
  }

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Online Attendance Management System</title>
<link rel="shortcut icon" href="alietlogo.jpg">
<meta charset="UTF-8">

<link rel="stylesheet" type="text/css" href="../css/tea_main.css">

<link rel="stylesheet" type="text/css" href="tea_style.css">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  

</head>
<body>
<center>
<!-- Menus started-->
<header>
	<div class="navbar">
  <h1 style="color:white">Online Student Attendance Management System </h1>
  </div>
  <div class="navbar">
    <a href="../logout.php">Logout</a>
  <a href="account.php">Update Student List</a>
  <a href="addstu.php">Add Student</a>
  <a href="report.php">Report</a>
  <a href="attendance.php">Attendance</a>
  <a href="teachers.php">Faculties</a>
  <a href="students.php">Students</a>
  <a href="index.php">Home</a>
</div>
<div class="message" style="color:white">
        <?php if(isset($success_msg)) echo $success_msg; if(isset($error_msg)) echo $error_msg; ?>
</div>
</header>

<div class="container">
<div class="content">

 <!-- <center style="color:white" > Select: <a href="#teacher" style="color:white">Teacher</a> | <a href="" style="color:white">Student</a> <br></center> -->

  <div class="row" id="student">



      <form method="post" class="form-horizontal col-md-6 col-md-offset-3">
      <center><h4 style="color:white">Add New Student Data</h4></center>
	  <br>
      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label" style="color:white">Reg. No.</label>
          <div class="col-sm-7">
            <input type="text" name="st_id"  class="form-control" id="input1" placeholder="Student Reg.No" />
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label" style="color:white">Name</label>
          <div class="col-sm-7">
            <input type="text" name="st_name"  class="form-control" id="input1" placeholder="Student Full Name" />
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label" style="color:white">Department</label>
          <div class="col-sm-7">
            <input type="text" name="st_dept"  class="form-control" id="input1" placeholder="Enter Department Name" />
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label" style="color:white">Batch</label>
          <div class="col-sm-7">
            <input type="text" name="st_batch"  class="form-control" id="input1" placeholder="Enter Batch Year" />
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label" style="color:white">Semester</label>
          <div class="col-sm-7">
            <input type="text" name="st_sem"  class="form-control" id="input1" placeholder="Enter Semester" />
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label" style="color:white">Email</label>
          <div class="col-sm-7">
            <input type="email" name="st_email"  class="form-control" id="input1" placeholder="Enter Student Email" />
          </div>
      </div>


      <input type="submit" class="btn btn-primary col-md-2 col-md-offset-8" value="ADD" name="std" />
    </form>

  </div>
  </div>
  </div>
  </center>
  </body>
<!-- Body ended  -->
</html>
