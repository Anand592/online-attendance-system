<?php

ob_start();
session_start();

if($_SESSION['name']!='oasis')
{
  header('location: ../index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Online Attendance Management System</title>
<link rel="shortcut icon" href="alietlogo.jpg">
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="../css/tea_main.css">

<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>

<header>
<div class="navbar">
	<div class="header">
  <h1 style="color:white">Online Student Attendance Management System </h1>
  </div>
  </div>
  <div class="navbar">
  <a href="../logout.php">Logout</a>

  <a href="account.php">Update Student List</a>
  <a href="addstu.php">Add Student</a>
  <a href="report.php">Report</a>
  <a href="attendance.php">Attendance</a>
  <a href="teachers.php">Faculties</a>
  <a href="students.php">Students</a>
  <a href="index.php">Home</a>

</div>

</header>

<center>
<div class="row">
    <div class="content">
      <p>One step solution for your class room :)</p>

  </div>

</div>
</center>

</body>
</html>
