<?php
$conn = mysqli_connect("localhost","root","","attsystem");
ob_start();
session_start();

if($_SESSION['name']!='oasis')
{

  header('location: ../index.php');
}
?>


<?php

//establishing connection
include('connect.php');

  try{

    //validation of empty fields
      if(isset($_POST['signup'])){

        if(empty($_POST['email'])){
          throw new Exception("Email cann't be empty.");
        }

          if(empty($_POST['uname'])){
             throw new Exception("Username cann't be empty.");
          }

            if(empty($_POST['pass'])){
               throw new Exception("Password cann't be empty.");
            }
              
              if(empty($_POST['fname'])){
                 throw new Exception("Username cann't be empty.");
              }
                if(empty($_POST['phone'])){
                   throw new Exception("Username cann't be empty.");
                }
                  if(empty($_POST['type'])){
                     throw new Exception("Username cann't be empty.");
                  }

        //insertion of data to database table admininfo
        $result = mysqli_query($conn,"insert into admininfo(username,password,email,fname,phone,type) values('$_POST[uname]','$_POST[pass]','$_POST[email]','$_POST[fname]','$_POST[phone]','$_POST[type]')");
        $success_msg="Signup Successfully!";

  
  }
}
  catch(Exception $e){
    $error_msg =$e->getMessage();
  }

?>

<!DOCTYPE html>
<html lang="en">

<!-- head started -->
<head>
<title>Online Attendance Management System </title>
<link rel="shortcut icon" href="alietlogo.jpg">
<meta charset="UTF-8">

  <link rel="stylesheet" type="text/css" href="../css/adm_main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
  <link rel="stylesheet" type="text/css" href="adm_style.css">

</head>
<!-- head ended -->

<!-- body started -->
<body>

    <!-- Menus started-->
    <header>
		<div class="navbar">
      <h1 style="color:#666362">Online Student Attendance Management System </h1>
	  </div>
      <div class="navbar">
      <a href="../logout.php">Logout</a>
      <a href="index.php">Add Teacher</a>
	  <a href="signup.php" >Create Users</a>

    </div>

    </header>
    <!-- Menus ended -->

<center>
<div class="container">
<h1 style="color:white">Create User</h1>
<p>    <?php
    if(isset($success_msg)) echo $success_msg;
    if(isset($error_msg)) echo $error_msg;
     ?>
       
     </p>
     <br>
<div class="content">

  <div class="row">
   
    <form method="post" class="form-horizontal col-md-6 col-md-offset-3">

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label" style="color:white">Email</label>
          <div class="col-sm-7">
            <input type="text" name="email"  class="form-control" id="input1" placeholder="Enter Email" />
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label" style="color:white">Username</label>
          <div class="col-sm-7">
            <input type="text" name="uname"  class="form-control" id="input1" placeholder="Choose Username" />
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label" style="color:white">Password</label>
          <div class="col-sm-7">
            <input type="password" name="pass"  class="form-control" id="input1" placeholder="Create a Password" />
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label" style="color:white">Full Name</label>
          <div class="col-sm-7">
            <input type="text" name="fname"  class="form-control" id="input1" placeholder="Enter Full Name" />
          </div>
      </div>

      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label" style="color:white">Phone Number</label>
          <div class="col-sm-7">
            <input type="text" name="phone"  class="form-control" id="input1" placeholder="Enter Phone Number" />
          </div>
      </div>


      <div class="form-group" class="radio">
      <label for="input1" class="col-sm-3 control-label" style="color:white">Role</label>
      <div class="col-sm-7">
        <label style="color:white">
          <input type="radio" name="type" id="optionsRadios1" value="student" > Student
        </label>
            <label style="color:white">
          <input type="radio" name="type" id="optionsRadios1" value="teacher"> Teacher
        </label>
        <label style="color:white">
          <input type="radio" name="type" id="optionsRadios1" value="admin"> Admin
        </label>
      </div>
      </div>

      <input type="submit" class="btn btn-primary col-md-2 col-md-offset-8" value="Signup" name="signup" />
    </form>
  </div>
    <br>
    <p><strong>Already have an account? <a href="../index.php">Login</a> here.</strong></p>

</div>
</div>
</center>

</body>
<!-- Body ended  -->

</html>
