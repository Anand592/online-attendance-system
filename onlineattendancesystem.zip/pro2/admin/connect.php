<?php
$conn = mysqli_connect("localhost","root","","attsystem");
if($conn)
	echo "";
else
echo "Failed to Connect:".mysql_error();
mysqli_select_db($conn,"attsystem") or die ('Cannot found database');

?>