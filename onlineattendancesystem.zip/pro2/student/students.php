<?php
$conn = mysqli_connect("localhost","root","","attsystem");
ob_start();
session_start();

if($_SESSION['name']!='oasis')
{
  header('location: login.php');
}
?>
<?php include('connect.php');?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Online Attendance Management System </title>
<link rel="shortcut icon" href="alietlogo.jpg">

<meta charset="UTF-8">
  
  <link rel="stylesheet" type="text/css" href="../css/stu_main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
   
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
   
  <link rel="stylesheet" href="styles.css" >
   
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
  <link rel="stylesheet" type="text/css" href="stu_style.css">



</head>
<body>

<header>
<div class="navbar">
  <h1 style="color:white">Online Attendance Management System </h1>
  </div>
  <div class="navbar">
<a href="../logout.php">Logout</a>
  <a href="report.php">My Report</a>
  <a href="students.php">Students</a>
  <a href="index.php">Home</a>

</div>

</header>

<center>
<div class="container">
<div class="row">

  <div class="content">
    <h3 style="color:white">Student List</h3>
    <br>

   <form method="post" action="" class="form-horizontal col-md-6 col-md-offset-3">
      <div class="form-group">
          <label for="input1" class="col-sm-3 control-label" style="color:white">Batch</label>
            <div class="col-sm-7">
                <input type="text" name="sr_batch"  class="form-control" id="input1" />
                
            </div>

      </div>
      <input type="submit" class="btn btn-primary col-md-3 col-md-offset-7" value="Go!" name="sr_btn" />
      
   </form>

   <div class="content"></div>
    <table class="table table-stripped">
      
      <thead>
      <tr>
        <th scope="col" style="color:white">Registration No.</th>
        <th scope="col" style="color:white">Name</th>
        <th scope="col" style="color:white">Department</th>
        <th scope="col" style="color:white">Batch</th>
        <th scope="col" style="color:white">Semester</th>
        <th scope="col" style="color:white">Email</th>
      </tr>
      </thead>
   <?php

    if(isset($_POST['sr_btn'])){
     
     $srbatch = $_POST['sr_batch'];
     $i=0;
     
     $all_query = mysqli_query($conn,"select * from students where students.st_batch = '$srbatch' order by st_id asc");
     
     while ($data = mysqli_fetch_array($all_query)) {
       $i++;
     
     ?>

     <tr>
       <td style="color:white"><?php echo $data['st_id']; ?></td>
       <td style="color:white"><?php echo $data['st_name']; ?></td>
       <td style="color:white"><?php echo $data['st_dept']; ?></td>
       <td style="color:white"><?php echo $data['st_batch']; ?></td>
       <td style="color:white"><?php echo $data['st_sem']; ?></td>
       <td style="color:white"><?php echo $data['st_email']; ?></td>
     </tr>

     <?php 
          } 
              }
      ?>
    </table>

  </div>

</div>
</div>
</center>

</body>
</html>
