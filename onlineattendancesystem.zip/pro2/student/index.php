<?php

ob_start();
session_start();

if($_SESSION['name']!='oasis')
{
  header('location: ../index.php');
}
?>

<!DOCTYPE html>
<html lang="en">

<!-- head started -->
<head>
<title>Online Attendance Management System</title>
<link rel="shortcut icon" href="alietlogo.jpg">

<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="../css/stu_main.css">

<link rel="stylesheet" type="text/css" href="style.css">

</head>
<!-- head ended -->

<!-- body started -->
<body>

<!-- Menus started-->
<header>
	<div class ="navbar">
	<div class="header">
  <h1 style="color:white">Online Student Attendance Management System </h1>
  </div>
  </div>
  <div class="navbar">
  <a href="../logout.php">Logout</a>
  <a href="report.php">My Report</a>
  <a href="students.php">Students</a>
  <a href="index.php">Home</a>

</div>

</header>
<!-- Menus ended -->

<center>

<!-- Content, Tables, Forms, Texts, Images started -->
<div class="row">
    <div class="content">
      <p>Be attentive and be regular :)</p>
    <img src="../img/tcr.png" height="200px" width="300px" />

  </div>

</div>
<!-- Contents, Tables, Forms, Images ended -->

</center>

</body>
<!-- Body ended  -->

</html>
